% Chapter 8: Example 8.16

%            Bilinear Transformation

%                  Simple example

%

c = [1,1]; d = [1,5,6]; T = 1;

[b,a] = bilinear(c,d,T)

%%b = 0.1500    0.1000   -0.0500

%%a = 1.0000    0.2000    0.0000