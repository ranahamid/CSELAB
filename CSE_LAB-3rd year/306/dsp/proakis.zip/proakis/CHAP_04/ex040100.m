% Chapter 4: Example 4.1:

%  X(z) using ztrans

%   x(n) = a^nu(n)

x = 'a^n';

X = ztrans(x)