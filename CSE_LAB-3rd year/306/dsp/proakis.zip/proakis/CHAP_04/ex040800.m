% Chapter 4: Example 4.8:

%  Check of residues in Example 4.7

%

b = [0,1]; a = [3,-4,1];

[R,p,C] = residuez(b,a)

%

[b,a] = residuez(R,p,C)