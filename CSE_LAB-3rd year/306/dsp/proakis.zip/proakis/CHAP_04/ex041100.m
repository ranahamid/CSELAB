% Chapter 4: Example 4.11:

%  zplane function:

%

b = [1,0]; a = [1, -0.9];

zplane(b,a); title('Pole-Zero Plot');

text(0.85,-0.1,'0.9');text(0.01,-0.1,'0');