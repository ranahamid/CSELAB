% Chapter 4: Example 4.8:

%  Check of residue functions rf2pfez and pfe2rfz

%

b = 1; a = poly([0.9,0.9,-0.9])

[R,p,c] = residuez(b,a)