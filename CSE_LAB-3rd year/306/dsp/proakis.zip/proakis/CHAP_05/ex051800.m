% Chapter 05: Example-5.18: olsave function use

%

n = 0:9; x = n+1; h = [1,0,-1]; N = 6;

%

y = ovrlpsav(x,h,N)

