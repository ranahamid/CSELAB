% Chapter 6 : Example 6.6 Frequency Sampling Form

%                           given h(n)

%

h = [1,2,3,2,1]/9;

[C,B,A] = dir2fs(h)



